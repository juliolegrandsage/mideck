# SPDX-FileCopyrightText: 2024 Justin Myers
#
# SPDX-License-Identifier: MIT
"""
Board stub for Pimoroni Badger 2350
 - port: raspberrypi
 - board_id: pimoroni_badger2350
 - NVM size: 4096
 - Included modules: _asyncio, _bleio, _bleio (HCI co-processor), _eve, _pixelmap, adafruit_bus_device, adafruit_pixelbuf, aesio, analogbufio, analogio, array, atexit, audiobusio, audiocore, audiodelays, audiofilewriter, audiofilters, audiofreeverb, audioi2sin, audiomixer, audiomp3, audiopwmio, audiospeed, binascii, bitbangio, bitmapfilter, bitmaptools, bitops, board, builtins, builtins.pow3, busdisplay, busio, busio.SPI, busio.UART, codeop, collections, countio, cyw43, digitalio, displayio, epaperdisplay, errno, floppyio, fontio, fourwire, framebufferio, getpass, gifio, hashlib, i2cdisplaybus, i2ctarget, imagecapture, io, ipaddress, jpegio, json, keypad, keypad.KeyMatrix, keypad.Keys, keypad.ShiftRegisterKeys, keypad_demux, keypad_demux.DemuxKeyMatrix, locale, lvfontio, math, mdns, memorymap, microcontroller, msgpack, neopixel_write, nvm, onewireio, os, os.getenv, paralleldisplaybus, pulseio, pwmio, qrio, rainbowio, random, re, rgbmatrix, rotaryio, rp2pio, rtc, sdcardio, select, sharpdisplay, socketpool, ssl, storage, struct, supervisor, supervisor.get_setting, synthio, sys, terminalio, tilepalettemapper, time, touchio, traceback, ulab, usb, usb_audio, usb_cdc, usb_hid, usb_host, usb_midi, usb_video, vectorio, warnings, watchdog, wifi, zlib
 - Frozen libraries: pcf85063a
"""

# Imports
import busio
import displayio
import microcontroller


# Board Info:
board_id: str


# Pins:
GP0: microcontroller.Pin  # GPIO0
LED: microcontroller.Pin  # GPIO0
LED0: microcontroller.Pin  # GPIO0
GP1: microcontroller.Pin  # GPIO1
LED1: microcontroller.Pin  # GPIO1
GP2: microcontroller.Pin  # GPIO2
LED2: microcontroller.Pin  # GPIO2
GP3: microcontroller.Pin  # GPIO3
LED3: microcontroller.Pin  # GPIO3
GP4: microcontroller.Pin  # GPIO4
SDA: microcontroller.Pin  # GPIO4
GP5: microcontroller.Pin  # GPIO5
SCL: microcontroller.Pin  # GPIO5
GP6: microcontroller.Pin  # GPIO6
SW_DOWN: microcontroller.Pin  # GPIO6
GP7: microcontroller.Pin  # GPIO7
SW_A: microcontroller.Pin  # GPIO7
GP9: microcontroller.Pin  # GPIO9
SW_B: microcontroller.Pin  # GPIO9
GP10: microcontroller.Pin  # GPIO10
SW_C: microcontroller.Pin  # GPIO10
GP11: microcontroller.Pin  # GPIO11
SW_UP: microcontroller.Pin  # GPIO11
GP12: microcontroller.Pin  # GPIO12
VBUS_SENSE: microcontroller.Pin  # GPIO12
GP13: microcontroller.Pin  # GPIO13
RTC_ALARM: microcontroller.Pin  # GPIO13
GP14: microcontroller.Pin  # GPIO14
SW_RESET: microcontroller.Pin  # GPIO14
GP15: microcontroller.Pin  # GPIO15
SW_INT: microcontroller.Pin  # GPIO15
GP16: microcontroller.Pin  # GPIO16
INKY_BUSY: microcontroller.Pin  # GPIO16
GP17: microcontroller.Pin  # GPIO17
INKY_CS: microcontroller.Pin  # GPIO17
GP18: microcontroller.Pin  # GPIO18
SCK: microcontroller.Pin  # GPIO18
GP19: microcontroller.Pin  # GPIO19
MOSI: microcontroller.Pin  # GPIO19
GP20: microcontroller.Pin  # GPIO20
INKY_DC: microcontroller.Pin  # GPIO20
GP21: microcontroller.Pin  # GPIO21
INKY_RST: microcontroller.Pin  # GPIO21
GP22: microcontroller.Pin  # GPIO22
SW_HOME: microcontroller.Pin  # GPIO22
GP26: microcontroller.Pin  # GPIO26
VBAT_SENSE: microcontroller.Pin  # GPIO26
GP28: microcontroller.Pin  # GPIO28
SENSE_1V1: microcontroller.Pin  # GPIO28
CHARGE_STAT: microcontroller.Pin  # CYW2


# Members:
def I2C() -> busio.I2C:
    """Returns the `busio.I2C` object for the board's designated I2C bus(es).
    The object created is a singleton, and uses the default parameter values for `busio.I2C`.
    """

def STEMMA_I2C() -> busio.I2C:
    """Returns the `busio.I2C` object for the board's designated I2C bus(es).
    The object created is a singleton, and uses the default parameter values for `busio.I2C`.
    """

def SPI() -> busio.SPI:
    """Returns the `busio.SPI` object for the board's designated SPI bus(es).
    The object created is a singleton, and uses the default parameter values for `busio.SPI`.
    """

"""Returns the `displayio.EPaperDisplay` object for the board's built in display.
The object created is a singleton, and uses the default parameter values for `displayio.EPaperDisplay`.
"""
DISPLAY: displayio.EPaperDisplay


# Unmapped:
#     { MP_ROM_QSTR(MP_QSTR_display), MP_ROM_PTR(&display_module) },
